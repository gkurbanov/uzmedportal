var image_1 = new KTImageInput('image_1');
var image_2 = new KTImageInput('image_2');

image_1.on('remove', function (imageInput) {
    var table_name = imageInput["remove"]["dataset"]["table"];
    var column = imageInput["remove"]["dataset"]["column"];
    var recordId = imageInput["remove"]["dataset"]["id"];
    var value = imageInput["remove"]["dataset"]["value"];

    $("div.image-input input#" + table_name.replace("_", "") + "-" + column).val(null);


    $.ajax({
        url: '/admin/ajax/remove-image',
        data: {
            table_name: table_name,
            column: column,
            record_id: recordId,
            value: value,
        },
        type: "GET",
        success: function (res) {
            if (res == true) {
                swal.fire({
                    title: 'Изображение удалено!',
                    type: 'error',
                    buttonsStyling: false,
                    confirmButtonText: 'Закрыть!',
                    confirmButtonClass: 'btn btn-primary font-weight-bold'
                });
            } else {
                swal.fire({
                    title: 'Уп-с, что-то пошло не так!',
                    type: 'error',
                    buttonsStyling: false,
                    confirmButtonText: 'Закрыть!',
                    confirmButtonClass: 'btn btn-danger font-weight-bold'
                });
            }
        },
        error: function (res) {
            console.log(res);
        }
    });
    // console.log(imageInput["remove"]["dataset"])
});

image_2.on('remove', function (imageInput) {
    var table_name = imageInput["remove"]["dataset"]["table"];
    var column = imageInput["remove"]["dataset"]["column"];
    var recordId = imageInput["remove"]["dataset"]["id"];
    var value = imageInput["remove"]["dataset"]["value"];

    $("div.image-input input#" + table_name.replace("_", "") + "-" + column).val(null);
    $.ajax({
        url: '/admin/ajax/remove-image',
        data: {
            table_name: table_name,
            column: column,
            record_id: recordId,
            value: value,
        },
        type: "GET",
        success: function (res) {
            if (res == true) {
                swal.fire({
                    title: 'Изображение удалено!',
                    type: 'error',
                    buttonsStyling: false,
                    confirmButtonText: 'Закрыть!',
                    confirmButtonClass: 'btn btn-primary font-weight-bold'
                });
            } else {
                swal.fire({
                    title: 'Уп-с, что-то пошло не так!',
                    type: 'error',
                    buttonsStyling: false,
                    confirmButtonText: 'Закрыть!',
                    confirmButtonClass: 'btn btn-danger font-weight-bold'
                });
            }
        },
        error: function (res) {
            console.log(res);
        }
    });
    // console.log(imageInput["remove"]["dataset"])
});